import { motion, AnimatePresence } from "framer-motion";
import { useGetExplore, useDeletePost, getGetExploreQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import Layout from "@/components/Layout";
import PostCard from "@/components/PostCard";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/lib/auth";

export default function Explore() {
  const { data: posts, isLoading } = useGetExplore();
  const deletePostMutation = useDeletePost();
  const queryClient = useQueryClient();
  const { currentUser } = useAuth();

  const handleDelete = (postId: number) => {
    deletePostMutation.mutate({ postId }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetExploreQueryKey() }),
    });
  };

  return (
    <Layout>
      <div
        className="min-h-full"
        style={{ background: "linear-gradient(180deg, #080c1a 0%, #0b1230 100%)" }}
      >
        <div className="px-4 pt-5 pb-4">
          <motion.h2
            className="text-2xl font-black text-white mb-1"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
          >
            Esplora
          </motion.h2>
          <p className="text-sm" style={{ color: "rgba(160,210,255,0.45)" }}>Scopri cosa sta succedendo</p>
        </div>

        <div className="px-4 pb-6 space-y-4 max-w-2xl mx-auto">
          {isLoading && (
            <>
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-36 rounded-2xl" style={{ background: "rgba(92,184,255,0.04)" }} />
              ))}
            </>
          )}

          {!isLoading && posts?.length === 0 && (
            <motion.div className="text-center py-20" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <p className="text-lg font-medium" style={{ color: "rgba(160,210,255,0.35)" }}>Nessun post ancora</p>
              <p className="text-sm mt-2" style={{ color: "rgba(160,210,255,0.25)" }}>Sii il primo a condividere qualcosa</p>
            </motion.div>
          )}

          <AnimatePresence>
            {posts?.map((post, i) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
              >
                <PostCard
                  post={post}
                  onDelete={currentUser?.id === post.authorId ? () => handleDelete(post.id) : undefined}
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </Layout>
  );
}
