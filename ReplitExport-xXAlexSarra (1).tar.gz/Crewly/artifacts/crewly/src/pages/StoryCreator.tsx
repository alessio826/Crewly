import { useCallback, useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useCreateStory, getGetStoriesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import Layout from "@/components/Layout";
import ImageUploadEditor from "@/components/ImageUploadEditor";

export default function StoryCreator() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createStory = useCreateStory();
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [caption, setCaption] = useState("");

  const handleImageReady = useCallback((url: string | null) => setImageDataUrl(url), []);

  const handlePublish = () => {
    if (!imageDataUrl) {
      toast({ title: "Aggiungi una foto prima di pubblicare", variant: "destructive" });
      return;
    }
    createStory.mutate(
      { data: { imageUrl: imageDataUrl, ...(caption.trim() ? { caption: caption.trim() } : {}) } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetStoriesQueryKey() });
          toast({ title: "Storia pubblicata! Visibile per 24 ore" });
          setLocation("/feed");
        },
        onError: (err: any) => {
          const msg = err?.data?.error ?? err?.message ?? "Errore sconosciuto";
          toast({ title: "Impossibile pubblicare la storia", description: msg, variant: "destructive" });
        },
      }
    );
  };

  return (
    <Layout>
      <div
        className="min-h-full px-4 pt-5 pb-8"
        style={{ background: "linear-gradient(180deg, #080c1a 0%, #0b1230 100%)" }}
      >
        <motion.div
          className="max-w-lg mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-2xl font-black text-white">Nuova storia</h2>
            <span className="text-xs px-2 py-1 rounded-full font-semibold" style={{ background: "rgba(92,184,255,0.12)", color: "#5cb8ff" }}>
              Scade in 24h
            </span>
          </div>

          <ImageUploadEditor onImageReady={handleImageReady} />

          {imageDataUrl && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4"
            >
              <Input
                value={caption}
                onChange={e => setCaption(e.target.value)}
                placeholder="Aggiungi una didascalia..."
                maxLength={150}
                className="h-12 rounded-xl text-white placeholder:text-white/25 border-0"
                style={{ background: "rgba(255,255,255,0.05)", outline: "1px solid rgba(92,184,255,0.1)" }}
              />
              <p className="text-xs text-right mt-1" style={{ color: "rgba(160,210,255,0.35)" }}>{caption.length}/150</p>
            </motion.div>
          )}

          <div className="flex gap-3 mt-5">
            <Button
              type="button"
              className="flex-1 h-12 rounded-xl text-white/50 border-0"
              style={{ background: "rgba(255,255,255,0.04)", outline: "1px solid rgba(92,184,255,0.1)" }}
              onClick={() => setLocation("/feed")}
            >
              Annulla
            </Button>
            <motion.div className="flex-1" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button
                onClick={handlePublish}
                disabled={createStory.isPending || !imageDataUrl}
                className="w-full h-12 font-bold rounded-xl border-0 text-white"
                style={{
                  background: imageDataUrl
                    ? "linear-gradient(135deg, #5cb8ff 0%, #5040ef 100%)"
                    : "rgba(92,184,255,0.2)",
                  boxShadow: imageDataUrl ? "0 4px 20px rgba(80,130,255,0.3)" : "none",
                }}
              >
                {createStory.isPending ? "Pubblicazione..." : "Pubblica storia"}
              </Button>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
