import React, { createContext, useContext, useState, useEffect } from "react";
import { User } from "@workspace/api-client-react";
import { setAuthTokenGetter } from "@workspace/api-client-react";

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  login: (token: string, user: User) => void;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Initialize auth from localStorage
    const token = localStorage.getItem("crewly_token");
    const storedUser = localStorage.getItem("crewly_user");
    
    if (token && storedUser) {
      try {
        const user = JSON.parse(storedUser);
        setCurrentUser(user);
        setAuthTokenGetter(() => token);
      } catch (e) {
        console.error("Failed to parse stored user", e);
        localStorage.removeItem("crewly_token");
        localStorage.removeItem("crewly_user");
      }
    }
    
    setIsLoading(false);
  }, []);

  const login = (token: string, user: User) => {
    localStorage.setItem("crewly_token", token);
    localStorage.setItem("crewly_user", JSON.stringify(user));
    setAuthTokenGetter(() => token);
    setCurrentUser(user);
  };

  const logout = () => {
    localStorage.removeItem("crewly_token");
    localStorage.removeItem("crewly_user");
    setAuthTokenGetter(() => null);
    setCurrentUser(null);
  };

  return (
    <AuthContext.Provider value={{ currentUser, isAuthenticated: !!currentUser, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
