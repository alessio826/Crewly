import { Router, type IRouter } from "express";
import { db, usersTable, commentsTable } from "@workspace/db";
import { eq, asc } from "drizzle-orm";
import { GetCommentsParams, CreateCommentParams, CreateCommentBody, DeleteCommentParams } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/posts/:postId/comments", async (req, res): Promise<void> => {
  const params = GetCommentsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  const comments = await db
    .select({ comment: commentsTable, author: usersTable })
    .from(commentsTable)
    .innerJoin(usersTable, eq(commentsTable.authorId, usersTable.id))
    .where(eq(commentsTable.postId, params.data.postId))
    .orderBy(asc(commentsTable.createdAt));

  res.json(comments.map(({ comment, author }) => ({
    id: comment.id,
    content: comment.content,
    postId: comment.postId,
    authorId: comment.authorId,
    createdAt: comment.createdAt.toISOString(),
    author: {
      id: author.id,
      username: author.username,
      displayName: author.displayName,
      email: author.email,
      bio: author.bio,
      avatarUrl: author.avatarUrl,
      createdAt: author.createdAt.toISOString(),
    },
  })));
});

router.post("/posts/:postId/comments", requireAuth, async (req, res): Promise<void> => {
  const params = CreateCommentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  const parsed = CreateCommentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const currentUser = req.currentUser!;
  const [comment] = await db
    .insert(commentsTable)
    .values({ content: parsed.data.content, postId: params.data.postId, authorId: currentUser.id })
    .returning();

  res.status(201).json({
    id: comment.id,
    content: comment.content,
    postId: comment.postId,
    authorId: comment.authorId,
    createdAt: comment.createdAt.toISOString(),
    author: {
      id: currentUser.id,
      username: currentUser.username,
      displayName: currentUser.displayName,
      email: currentUser.email,
      bio: currentUser.bio,
      avatarUrl: currentUser.avatarUrl,
      createdAt: currentUser.createdAt.toISOString(),
    },
  });
});

router.delete("/comments/:commentId", requireAuth, async (req, res): Promise<void> => {
  const params = DeleteCommentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid commentId" });
    return;
  }

  const [comment] = await db.select().from(commentsTable).where(eq(commentsTable.id, params.data.commentId));
  if (!comment) {
    res.status(404).json({ error: "Comment not found" });
    return;
  }
  if (comment.authorId !== req.currentUser!.id) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  await db.delete(commentsTable).where(eq(commentsTable.id, params.data.commentId));
  res.sendStatus(204);
});

export default router;
