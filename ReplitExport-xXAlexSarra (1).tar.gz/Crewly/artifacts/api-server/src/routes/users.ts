import { Router, type IRouter } from "express";
import { db, usersTable, followsTable, postsTable } from "@workspace/db";
import { eq, and, count, or, ilike } from "drizzle-orm";
import {
  GetUserParams,
  GetFollowersParams,
  GetFollowingParams,
  GetUserPostsParams,
  FollowUserParams,
  UnfollowUserParams,
  UpdateProfileBody,
  SearchUsersQueryParams,
} from "@workspace/api-zod";
import { requireAuth, optionalAuth } from "../middlewares/auth";
import { buildPostWithMeta } from "./posts";

const router: IRouter = Router();

function formatUser(user: {
  id: number; username: string; displayName: string; email: string;
  bio: string | null; website?: string | null; avatarUrl: string | null; createdAt: Date;
}) {
  return {
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    email: user.email,
    bio: user.bio,
    website: user.website ?? null,
    avatarUrl: user.avatarUrl,
    createdAt: user.createdAt.toISOString(),
  };
}

// PATCH /users/me — update profile
router.patch("/users/me", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const currentUser = req.currentUser!;
  const { username, displayName, bio, website, avatarUrl } = parsed.data;

  // If username change requested, check uniqueness
  if (username !== undefined && username !== currentUser.username) {
    const [existing] = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.username, username.toLowerCase()));
    if (existing) {
      res.status(400).json({ error: `Username @${username} già in uso` });
      return;
    }
  }

  const updates: Partial<{ username: string; displayName: string; bio: string; website: string; avatarUrl: string }> = {};
  if (username !== undefined) updates.username = username.toLowerCase();
  if (displayName !== undefined) updates.displayName = displayName;
  if (bio !== undefined) updates.bio = bio;
  if (website !== undefined) updates.website = website;
  if (avatarUrl !== undefined) updates.avatarUrl = avatarUrl;

  const [updated] = await db
    .update(usersTable)
    .set(updates)
    .where(eq(usersTable.id, currentUser.id))
    .returning();

  res.json(formatUser(updated));
});

// GET /users/search?q=
router.get("/users/search", optionalAuth, async (req, res): Promise<void> => {
  const parsed = SearchUsersQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Missing q parameter" });
    return;
  }

  const q = `%${parsed.data.q}%`;
  const users = await db
    .select()
    .from(usersTable)
    .where(or(ilike(usersTable.username, q), ilike(usersTable.displayName, q)))
    .limit(20);

  const currentUserId = req.currentUser?.id;

  const results = await Promise.all(
    users.map(async (user) => {
      const [followersResult] = await db
        .select({ count: count() })
        .from(followsTable)
        .where(eq(followsTable.followingId, user.id));

      const [followingResult] = await db
        .select({ count: count() })
        .from(followsTable)
        .where(eq(followsTable.followerId, user.id));

      const [postsResult] = await db
        .select({ count: count() })
        .from(postsTable)
        .where(eq(postsTable.authorId, user.id));

      let isFollowing = false;
      if (currentUserId) {
        const [follow] = await db
          .select()
          .from(followsTable)
          .where(and(
            eq(followsTable.followerId, currentUserId),
            eq(followsTable.followingId, user.id),
          ));
        isFollowing = !!follow;
      }

      return {
        ...formatUser(user),
        followersCount: followersResult?.count ?? 0,
        followingCount: followingResult?.count ?? 0,
        postsCount: postsResult?.count ?? 0,
        isFollowing,
      };
    })
  );

  res.json(results);
});

router.get("/users/:userId", optionalAuth, async (req, res): Promise<void> => {
  const params = GetUserParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid userId" });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, params.data.userId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const [followersResult] = await db
    .select({ count: count() })
    .from(followsTable)
    .where(eq(followsTable.followingId, user.id));

  const [followingResult] = await db
    .select({ count: count() })
    .from(followsTable)
    .where(eq(followsTable.followerId, user.id));

  const [postsResult] = await db
    .select({ count: count() })
    .from(postsTable)
    .where(eq(postsTable.authorId, user.id));

  let isFollowing = false;
  if (req.currentUser) {
    const [follow] = await db
      .select()
      .from(followsTable)
      .where(and(
        eq(followsTable.followerId, req.currentUser.id),
        eq(followsTable.followingId, user.id),
      ));
    isFollowing = !!follow;
  }

  res.json({
    ...formatUser(user),
    followersCount: followersResult?.count ?? 0,
    followingCount: followingResult?.count ?? 0,
    postsCount: postsResult?.count ?? 0,
    isFollowing,
  });
});

router.post("/users/:userId/follow", requireAuth, async (req, res): Promise<void> => {
  const params = FollowUserParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid userId" });
    return;
  }

  const currentUser = req.currentUser!;
  if (currentUser.id === params.data.userId) {
    res.status(400).json({ error: "Cannot follow yourself" });
    return;
  }

  await db
    .insert(followsTable)
    .values({ followerId: currentUser.id, followingId: params.data.userId })
    .onConflictDoNothing();

  res.json({ ok: true });
});

router.post("/users/:userId/unfollow", requireAuth, async (req, res): Promise<void> => {
  const params = UnfollowUserParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid userId" });
    return;
  }

  const currentUser = req.currentUser!;
  await db
    .delete(followsTable)
    .where(and(
      eq(followsTable.followerId, currentUser.id),
      eq(followsTable.followingId, params.data.userId),
    ));

  res.json({ ok: true });
});

router.get("/users/:userId/followers", async (req, res): Promise<void> => {
  const params = GetFollowersParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid userId" });
    return;
  }

  const followers = await db
    .select({ user: usersTable })
    .from(followsTable)
    .innerJoin(usersTable, eq(followsTable.followerId, usersTable.id))
    .where(eq(followsTable.followingId, params.data.userId));

  res.json(followers.map(r => formatUser(r.user)));
});

router.get("/users/:userId/following", async (req, res): Promise<void> => {
  const params = GetFollowingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid userId" });
    return;
  }

  const following = await db
    .select({ user: usersTable })
    .from(followsTable)
    .innerJoin(usersTable, eq(followsTable.followerId, usersTable.id))
    .where(eq(followsTable.followerId, params.data.userId));

  res.json(following.map(r => formatUser(r.user)));
});

router.get("/users/:userId/posts", optionalAuth, async (req, res): Promise<void> => {
  const params = GetUserPostsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid userId" });
    return;
  }

  const posts = await buildPostWithMeta(params.data.userId, req.currentUser?.id);
  res.json(posts);
});

export default router;
