import { Router, type IRouter } from "express";
import { db, usersTable, postsTable, likesTable, commentsTable } from "@workspace/db";
import { eq, and, count, desc, inArray } from "drizzle-orm";
import {
  CreatePostBody,
  GetPostParams,
  DeletePostParams,
  LikePostParams,
  UnlikePostParams,
} from "@workspace/api-zod";
import { requireAuth, optionalAuth } from "../middlewares/auth";

const router: IRouter = Router();

export async function buildPostWithMeta(authorId?: number, currentUserId?: number) {
  const whereClause = authorId !== undefined
    ? eq(postsTable.authorId, authorId)
    : undefined;

  const rawPosts = whereClause
    ? await db.select().from(postsTable).where(whereClause).orderBy(desc(postsTable.createdAt))
    : await db.select().from(postsTable).orderBy(desc(postsTable.createdAt));

  if (rawPosts.length === 0) return [];

  const postIds = rawPosts.map(p => p.id);
  const authorIds = [...new Set(rawPosts.map(p => p.authorId))];

  const authors = await db.select().from(usersTable).where(inArray(usersTable.id, authorIds));
  const authorMap = new Map(authors.map(u => [u.id, u]));

  const likeCounts = await db
    .select({ postId: likesTable.postId, count: count() })
    .from(likesTable)
    .where(inArray(likesTable.postId, postIds))
    .groupBy(likesTable.postId);
  const likeCountMap = new Map(likeCounts.map(l => [l.postId, l.count]));

  const commentCounts = await db
    .select({ postId: commentsTable.postId, count: count() })
    .from(commentsTable)
    .where(inArray(commentsTable.postId, postIds))
    .groupBy(commentsTable.postId);
  const commentCountMap = new Map(commentCounts.map(c => [c.postId, c.count]));

  let likedPostIds = new Set<number>();
  if (currentUserId) {
    const likedRows = await db
      .select({ postId: likesTable.postId })
      .from(likesTable)
      .where(and(
        eq(likesTable.userId, currentUserId),
        inArray(likesTable.postId, postIds),
      ));
    likedPostIds = new Set(likedRows.map(r => r.postId));
  }

  return rawPosts.map(post => {
    const author = authorMap.get(post.authorId)!;
    return {
      id: post.id,
      content: post.content,
      imageUrl: post.imageUrl,
      authorId: post.authorId,
      createdAt: post.createdAt.toISOString(),
      likesCount: likeCountMap.get(post.id) ?? 0,
      commentsCount: commentCountMap.get(post.id) ?? 0,
      isLiked: likedPostIds.has(post.id),
      author: {
        id: author.id,
        username: author.username,
        displayName: author.displayName,
        email: author.email,
        bio: author.bio,
        avatarUrl: author.avatarUrl,
        createdAt: author.createdAt.toISOString(),
      },
    };
  });
}

router.post("/posts", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreatePostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const currentUser = req.currentUser!;
  const [post] = await db
    .insert(postsTable)
    .values({ ...parsed.data, authorId: currentUser.id })
    .returning();

  res.status(201).json({
    id: post.id,
    content: post.content,
    imageUrl: post.imageUrl,
    authorId: post.authorId,
    createdAt: post.createdAt.toISOString(),
    likesCount: 0,
    commentsCount: 0,
    isLiked: false,
    author: {
      id: currentUser.id,
      username: currentUser.username,
      displayName: currentUser.displayName,
      email: currentUser.email,
      bio: currentUser.bio,
      avatarUrl: currentUser.avatarUrl,
      createdAt: currentUser.createdAt.toISOString(),
    },
  });
});

router.get("/posts/:postId", optionalAuth, async (req, res): Promise<void> => {
  const params = GetPostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, params.data.postId));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  const [author] = await db.select().from(usersTable).where(eq(usersTable.id, post.authorId));
  const [likesResult] = await db.select({ count: count() }).from(likesTable).where(eq(likesTable.postId, post.id));
  const [commentsResult] = await db.select({ count: count() }).from(commentsTable).where(eq(commentsTable.postId, post.id));

  let isLiked = false;
  if (req.currentUser) {
    const [like] = await db.select().from(likesTable).where(and(
      eq(likesTable.userId, req.currentUser.id),
      eq(likesTable.postId, post.id),
    ));
    isLiked = !!like;
  }

  res.json({
    id: post.id,
    content: post.content,
    imageUrl: post.imageUrl,
    authorId: post.authorId,
    createdAt: post.createdAt.toISOString(),
    likesCount: likesResult?.count ?? 0,
    commentsCount: commentsResult?.count ?? 0,
    isLiked,
    author: author ? {
      id: author.id,
      username: author.username,
      displayName: author.displayName,
      email: author.email,
      bio: author.bio,
      avatarUrl: author.avatarUrl,
      createdAt: author.createdAt.toISOString(),
    } : null,
  });
});

router.delete("/posts/:postId", requireAuth, async (req, res): Promise<void> => {
  const params = DeletePostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  const currentUser = req.currentUser!;
  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, params.data.postId));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }
  if (post.authorId !== currentUser.id) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  await db.delete(postsTable).where(eq(postsTable.id, params.data.postId));
  res.sendStatus(204);
});

router.post("/posts/:postId/like", requireAuth, async (req, res): Promise<void> => {
  const params = LikePostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  await db
    .insert(likesTable)
    .values({ userId: req.currentUser!.id, postId: params.data.postId })
    .onConflictDoNothing();

  res.json({ ok: true });
});

router.post("/posts/:postId/unlike", requireAuth, async (req, res): Promise<void> => {
  const params = UnlikePostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  await db
    .delete(likesTable)
    .where(and(
      eq(likesTable.userId, req.currentUser!.id),
      eq(likesTable.postId, params.data.postId),
    ));

  res.json({ ok: true });
});

export default router;
