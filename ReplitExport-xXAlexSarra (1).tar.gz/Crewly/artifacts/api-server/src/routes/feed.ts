import { Router, type IRouter } from "express";
import { db, postsTable, followsTable, likesTable, commentsTable, usersTable } from "@workspace/db";
import { eq, desc, inArray, count, and } from "drizzle-orm";
import { requireAuth, optionalAuth } from "../middlewares/auth";

const router: IRouter = Router();

async function getPostsWithMeta(postIds: number[], currentUserId?: number) {
  if (postIds.length === 0) return [];

  const posts = await db.select().from(postsTable).where(inArray(postsTable.id, postIds)).orderBy(desc(postsTable.createdAt));
  const authorIds = [...new Set(posts.map(p => p.authorId))];
  const authors = await db.select().from(usersTable).where(inArray(usersTable.id, authorIds));
  const authorMap = new Map(authors.map(u => [u.id, u]));

  const likeCounts = await db
    .select({ postId: likesTable.postId, count: count() })
    .from(likesTable)
    .where(inArray(likesTable.postId, postIds))
    .groupBy(likesTable.postId);
  const likeCountMap = new Map(likeCounts.map(l => [l.postId, l.count]));

  const commentCounts = await db
    .select({ postId: commentsTable.postId, count: count() })
    .from(commentsTable)
    .where(inArray(commentsTable.postId, postIds))
    .groupBy(commentsTable.postId);
  const commentCountMap = new Map(commentCounts.map(c => [c.postId, c.count]));

  let likedPostIds = new Set<number>();
  if (currentUserId) {
    const likedRows = await db
      .select({ postId: likesTable.postId })
      .from(likesTable)
      .where(and(eq(likesTable.userId, currentUserId), inArray(likesTable.postId, postIds)));
    likedPostIds = new Set(likedRows.map(r => r.postId));
  }

  return posts.map(post => {
    const author = authorMap.get(post.authorId)!;
    return {
      id: post.id,
      content: post.content,
      imageUrl: post.imageUrl,
      authorId: post.authorId,
      createdAt: post.createdAt.toISOString(),
      likesCount: likeCountMap.get(post.id) ?? 0,
      commentsCount: commentCountMap.get(post.id) ?? 0,
      isLiked: likedPostIds.has(post.id),
      author: {
        id: author.id,
        username: author.username,
        displayName: author.displayName,
        email: author.email,
        bio: author.bio,
        avatarUrl: author.avatarUrl,
        createdAt: author.createdAt.toISOString(),
      },
    };
  });
}

router.get("/feed", requireAuth, async (req, res): Promise<void> => {
  const currentUser = req.currentUser!;

  const following = await db
    .select({ followingId: followsTable.followingId })
    .from(followsTable)
    .where(eq(followsTable.followerId, currentUser.id));

  const followingIds = following.map(f => f.followingId);
  const allIds = [...followingIds, currentUser.id];

  const posts = await db
    .select({ id: postsTable.id })
    .from(postsTable)
    .where(inArray(postsTable.authorId, allIds))
    .orderBy(desc(postsTable.createdAt))
    .limit(50);

  const postIds = posts.map(p => p.id);
  const result = await getPostsWithMeta(postIds, currentUser.id);
  res.json(result);
});

router.get("/explore", optionalAuth, async (req, res): Promise<void> => {
  const posts = await db
    .select({ id: postsTable.id })
    .from(postsTable)
    .orderBy(desc(postsTable.createdAt))
    .limit(50);

  const postIds = posts.map(p => p.id);
  const result = await getPostsWithMeta(postIds, req.currentUser?.id);
  res.json(result);
});

router.get("/feed/stats", requireAuth, async (req, res): Promise<void> => {
  const currentUser = req.currentUser!;

  const [postsResult] = await db
    .select({ count: count() })
    .from(postsTable)
    .where(eq(postsTable.authorId, currentUser.id));

  const userPosts = await db
    .select({ id: postsTable.id })
    .from(postsTable)
    .where(eq(postsTable.authorId, currentUser.id));

  let totalLikes = 0;
  if (userPosts.length > 0) {
    const postIds = userPosts.map(p => p.id);
    const [likesResult] = await db
      .select({ count: count() })
      .from(likesTable)
      .where(inArray(likesTable.postId, postIds));
    totalLikes = likesResult?.count ?? 0;
  }

  const [followersResult] = await db
    .select({ count: count() })
    .from(followsTable)
    .where(eq(followsTable.followingId, currentUser.id));

  const [followingResult] = await db
    .select({ count: count() })
    .from(followsTable)
    .where(eq(followsTable.followerId, currentUser.id));

  res.json({
    totalPosts: postsResult?.count ?? 0,
    totalLikes,
    followersCount: followersResult?.count ?? 0,
    followingCount: followingResult?.count ?? 0,
  });
});

export default router;
