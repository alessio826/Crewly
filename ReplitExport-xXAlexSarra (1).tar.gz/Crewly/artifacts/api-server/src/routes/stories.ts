import { Router, type IRouter } from "express";
import { db, usersTable, storiesTable, followsTable } from "@workspace/db";
import { eq, and, gt, inArray } from "drizzle-orm";
import { CreateStoryBody, DeleteStoryParams, GetUserStoriesParams } from "@workspace/api-zod";
import { requireAuth, optionalAuth } from "../middlewares/auth";

const router: IRouter = Router();

function formatStory(story: any, author: any) {
  return {
    id: story.id,
    authorId: story.authorId,
    imageUrl: story.imageUrl,
    caption: story.caption ?? null,
    createdAt: story.createdAt.toISOString(),
    expiresAt: story.expiresAt.toISOString(),
    author: {
      id: author.id,
      username: author.username,
      displayName: author.displayName,
      email: author.email,
      bio: author.bio,
      website: author.website ?? null,
      avatarUrl: author.avatarUrl,
      createdAt: author.createdAt.toISOString(),
    },
  };
}

router.get("/stories", optionalAuth, async (req, res): Promise<void> => {
  const now = new Date();
  let stories;

  if (req.currentUser) {
    const following = await db
      .select({ followingId: followsTable.followingId })
      .from(followsTable)
      .where(eq(followsTable.followerId, req.currentUser.id));

    const followingIds = following.map(f => f.followingId);
    const allIds = [...followingIds, req.currentUser.id];

    stories = await db
      .select({ story: storiesTable, author: usersTable })
      .from(storiesTable)
      .innerJoin(usersTable, eq(storiesTable.authorId, usersTable.id))
      .where(and(inArray(storiesTable.authorId, allIds), gt(storiesTable.expiresAt, now)));
  } else {
    stories = await db
      .select({ story: storiesTable, author: usersTable })
      .from(storiesTable)
      .innerJoin(usersTable, eq(storiesTable.authorId, usersTable.id))
      .where(gt(storiesTable.expiresAt, now));
  }

  res.json(stories.map(({ story, author }) => formatStory(story, author)));
});

router.get("/users/:userId/stories", optionalAuth, async (req, res): Promise<void> => {
  const parsed = GetUserStoriesParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid userId" });
    return;
  }

  const now = new Date();
  const stories = await db
    .select({ story: storiesTable, author: usersTable })
    .from(storiesTable)
    .innerJoin(usersTable, eq(storiesTable.authorId, usersTable.id))
    .where(and(eq(storiesTable.authorId, parsed.data.userId), gt(storiesTable.expiresAt, now)));

  res.json(stories.map(({ story, author }) => formatStory(story, author)));
});

router.post("/stories", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateStoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const currentUser = req.currentUser!;
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

  const [story] = await db
    .insert(storiesTable)
    .values({
      imageUrl: parsed.data.imageUrl,
      caption: parsed.data.caption ?? null,
      authorId: currentUser.id,
      expiresAt,
    })
    .returning();

  res.status(201).json(formatStory(story, currentUser));
});

router.delete("/stories/:storyId", requireAuth, async (req, res): Promise<void> => {
  const parsed = DeleteStoryParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid storyId" });
    return;
  }

  const currentUser = req.currentUser!;
  await db
    .delete(storiesTable)
    .where(and(eq(storiesTable.id, parsed.data.storyId), eq(storiesTable.authorId, currentUser.id)));

  res.status(204).end();
});

export default router;
